// 商户详情
const merchantView = '/merchants/v1/merchant/view';
// 商户列表
const merchantIndex = '/merchants/v1/merchant/index';

export {
    merchantView,
    merchantIndex
}
