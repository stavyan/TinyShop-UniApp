<template>
	<view class="footprint">
		<!--日历控件-->
		<rf-calendar
				class="date"
				:insert="true"
				:lunar="true"
				:start-date="'2019-3-2'"
				:end-date="'2019-5-20'"
				@change="handleDateChange"
		/>
		<!--足迹列表-->
    <rf-swipe-action class="rf-list" v-if="footPrintList.length > 0">
      <rf-swipe-action-item
          :options="options"
          :info="item"
          @action="bindClick"
          :key="index"
          class="rf-swipe-item"
          v-for="(item, index) in footPrintList">
          <view class="rf-list-item" @tap="navTo(`/pages/product/product?id=${item.product.id}`)">
          <view class="left">
            <image class="image" :isPreviewImage="false" :src="item.product && item.product.picture"></image>
          </view>
          <view class="mid">
            <view class="title in2line">{{ item.product && item.product.name }}</view>
            <view class="data">
              <view class="item"><text class="iconfont icontuandui"></text>推荐 {{item.product && item.product.collect_num || 0 }}</view>
              <view class="item"><text class="iconfont iconkechakan"></text>浏览 {{item.product && item.product.view || 0 }}</view>
            </view>
            <view class="state-wrapper">
              <text class="state" v-if="parseInt(item.product && item.product.product_status) === 0">
                失效
              </text>
            </view>
            <view class="bottom">
              <text class="price">{{ item.product && item.product.minPriceSku.price }}</text>
              <text>{{ item.created_at | time }}</text>
            </view>
          </view>
        </view>
      </rf-swipe-action-item>
      <rf-load-more :status="loadingType" v-if="footPrintList.length > 0"/>
    </rf-swipe-action>
		<!--足迹列表为0-->
		<rf-empty info="暂无足迹列表" v-if="footPrintList.length === 0"></rf-empty>
		<!--加载动画-->
		<rf-loading v-if="loading"></rf-loading>
	</view>
</template>

<script>
    /**
     * @des 我的足迹
     *
     * @author stav stavyan@qq.com
     * @date 2019-11-22 10:47
     * @copyright 2019
     */
    import {footPrintDel, footPrintList} from "@/api/userInfo";
    import rfLoadMore from '@/components/rf-load-more/rf-load-more';
    import rfCalendar from "@/components/rf-calendar/rf-calendar";
    import rfSwipeAction from '@/components/rf-swipe-action/rf-swipe-action';
    import rfSwipeActionItem from '@/components/rf-swipe-action-item/rf-swipe-action-item';
    import moment from '@/common/moment';

    export default {
        components: {
            rfLoadMore,
            rfCalendar,
            rfSwipeAction,
            rfSwipeActionItem
        },
        data() {
            return {
                footPrintList: [],
                page: 1,
                loadingType: 'more',
                token: null,
                startTime: moment().startOf('day').format('X'),
                endTime: moment().endOf('day').format('X'),
                options: [
                    {text: '删除', style: {backgroundColor: '#fa436a'}}
                ],
                loading: true,
                empty: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMMAAACtCAYAAAANgcuAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6Rjk5MjI3NjM1NUJGMTFFOThGRTZGQUIxMjY1ODk1QTkiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6Rjk5MjI3NjQ1NUJGMTFFOThGRTZGQUIxMjY1ODk1QTkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpGOTkyMjc2MTU1QkYxMUU5OEZFNkZBQjEyNjU4OTVBOSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpGOTkyMjc2MjU1QkYxMUU5OEZFNkZBQjEyNjU4OTVBOSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvBPHdgAAEY/SURBVHja7H3bkiTHcWVe+jIYALyAlyEl7Wofdt/WMF8h4iuIr4C+Yv9C/ApRXwG87T5ozWS7KwwpihcAw5nprswtz4oTeeKEe2Q2egaqGXaZtWVWZlZWdZWf8HPcPTz6eZ67c3l8/eeb/2HbwzQ/GYf+mW3tOfZty9free+e/Nromr2P6fj6IX2Gie7Fx/T8QJ95usP7z9P0M+z3w/BldG7Pw16P1/D+8pnm42fuy++Vzy3/w/E89vFcr+Hr9Ly+nu9hx6dpOn5vQ/repvS9DfS9lcfw/KcffdC/Tvvrzw0MR4P97Gi4bPCegRfn7Hl0nXd8w+DNgN3nU7qXPcdx3uqDj0fXbABCjXo5xltcp/v6Wu8+R0M0o8zbZJww1mKfz4lRu+dwXM8dDdmMOm+9Y1P67HpMXvfsxz94/LPXaX9Dd0YPb+Q2g4bxMwjYyHl/C0ibXwgZPhsvG7UHCD3Hr/FApsZu+54Bm+F6Ru+BpQUE73Uw2JZB8zm93gMQ/uyYHi+/56Ha12MKDj7+Jh5nBYYAIMvf1iiv3uIeVKgABhs9g0SNW72JHtN7q+Gy0XseAucZNOopPMDwPYoROhlrBADvvOdJ1AsoqG4Ph+UvA4M+G4xatx4A7O/2MNF9pyev29Yuzs34x6EPQdGiQN8WBFs0RumQN+LrsbvSIm9EV4NWALToFJ63jJZpUER/+LiO9npOadVy7fFzXIxjBoU3uusoz4DQ4xfj6i2OZ5+9056BBTJTIQ8gETXaM+IrCKIRnLdq3OoVIorkGSqP3uwRlMp4AFFq5YFHub4jjCtao5Qo4v0e5dGHGb5dY0AACMyAAQwe7fHHIODn5g2mxavhc5yAARH9TtOkaIT3DP4u1GgIAMPawANGdA9+ne5HI7ke07/IK0QeIdIPEW3xPEBEhSLwtEQygAIQ4HUARP4cgVdQ77BQl3HI2zelFc6WJnmjfvT8PpGiiProCN/yLnvpT4vLt+iSegG+1xZ10pFcBbACQylO61r2AMs1acQHNVIqxFGjlmAugDKfRmp4henoIewnwc/Codd31jNw9Mgz+PsIZI/qePQJx6Nw6Za3ieiPFzHCdQwUBU3r9ct3Qnw88g57nnsA8MKu2JoHsL9CPwgd0pBqyxPwNfrVwkMsIDkB7d2mSRZa1bDpHj1wlxF8uKO+4OiRdy4Sr1uURp97I78+jyI2bKyeEXsRJO98lROg6FFEb1gYrzz/sArdHaHR7BVIFxSepE/aYT7t/8WEVtX475MriAx77+v36IeW6I00wZ4cwBagRqImUVRHt9Ho3/IYfA1G/NV455PB270coKgo9nIMkX5YQDN3+Q+gUMC88wJ6rzeIQqFR+LMFlK17VGFL8QoaIYqMuOVB1CNE4VXOG2jI04v4bGkEV2zbyO7cA7oAfzl6RJEhjwZxdCgyfoz6RonsOlAjNgcGxDsPhrt4Ay/u713jZYu9vMCWh9gzumtSLAqBekm2SCCH/5sT2/cojnfcyywXFKvB7z1dwAYf5Q1OAOsKYCCZloXy3FXAURCwkH7nwXAXr6CCd0+dkOcpomPLCJzOmbGOF2Nl7BGtibyDZpK3sscel98KiXq1RXq/rbqiQg+QaDZjhTeI+HvkJbKOIP6fI0T9SoHMK8DomSopdXrnQ6t7w6N7+L1XP3QXsPRVJnQOC+a8kb1VQOd5DqY/d4kGeaUVe7yKd19OlCk4piAk6nmHPXkEGH7lBabyOV//JrzCWwWGqN4nMvqtcy3K5BmvJ3JbEaAo/r/Hk3jJLK80olVpuueeXDYBw8aIXwBjIyTaolNZIxymwohZF9zSOU8w8/ZNAuKtAYOCwCuj9ow8yhkoEJQu8WjvGT9THS6i80DgnWsBxSuI84zZE7f2+J//vOaj3nt01f35xatuPL7f1dVF9+rV7bLlBx+zfe+B+9jWHi9f3XTXV5fVFufsged8/c3tKeyKc/Yc4Hn83lV3OMzLsUfXp8/z4uXp8+A5jtnv9S//7w/5R7XzdhxbPsbX8OO//7ef9W+VZuA4vxr13tIJD0jR+0QeIgqjtkqmPU0QAcHLD3iiWIHgRZJgsLw9HN/PDN22ZtT2hwdAgv0ICPbAa2HMtuXnAAL2+bk9Li/GfG4cTyFZO2ZeBECAwatRs2FfXY6VkfNWj+k9+V5nDwYtk0ZUSEd+Hf09SoRjHo3iSFErzOmBw6M6XqnE1j08Lu8ZvjsvwCm0g+Hyd2IGDUMHSOw6AwGuZ6/A1x/of8Rr2eDtGAz/4mjYDBQPIDhnxg+vYkYLrwHAwJCf//lVYdBq6GrknqEzQPgebw1N8ipBPaOOwqbRHANEicwgD8cfIBrhVSS3aoeiCFJEnfS10cwy75juhzqBKCQM3gyXjd4M3SgUtnjg+shrgDJ5FGm8Gly6xJSKAQJg2ANUiUdvO6ZGHBm0R4c8IL1VniEy+Lu+PprG2YoAtcKmHm1qXbsllj2aEx2LaJUXXTID87ykGTFGehuBeaRnY8c1DATQLNtn6qT0yQzd3tPTDNjyOZw3r2BeAPv2+cx47ZjSG9UGbOzwDp7B4/hb5Rn2hET3zkHWc/AGyv29BNlWaXXLG7TyBVFEyIsAeTqBX6/3ZENjgzUDtu8C1IYpEkABg2dvwcIb4LDv1p7DQ7BnYW9kW3gBT2zzZ+V90xPmIU5ieSgEties2bgZKCqqPWF9tmDYM+94jzdpXRdNqI/0QEsj7Em4RSHOVjJMKVIVDg0oEu7JBud5VwUBU5+tgIRGnhRwHHHyKKt6DG9fI0/juBrwy1ensG1k1AwQPR+95q0IrapeiMKjChQYth1nT7CVJ/DyC3uoUwsUrQrRFgXaSo55HiN6nGjTdDSkQxUhgrdQb8LegikUnjMobN88A78Wwl0frCV0PxLd3CDgBI4+ewktD1dvwMbf0hrDOQNAaY5Gl1qv78llRzVAWhah10T5gZZeiCiRaoTIwFtTNVu1R0ie4fVKP8ygELbUiBNoE8KkDAKNJrF+sD97PesJ9TIaxsV7RkDwwrF2/JKiVHbedIQBAslCRIuULkXRpLP3DNpkq6UbWjSIo0XRaO8Zf0so7523EHmDSBB70aGtDHTO/jr/B0opIkNjI+TQ6JTnmw8hCJgiXSy5gXZAg0HAlAmhWPUCesze4zYB2IBsgLA/0CQDBOgU5ygQmo2Sb29NNEkzypxjaPHYVhsWHe23HpHhR4Dqqb7fG81bNKiVY/CAwAVzGRRdWR36nJJgSkfwXJNmJyrSLwaoIMA1TJN09PYGKADHtgoEe4574vPAsHFvAAHRJfYa+H/hHWD0dtyORaO/eo+zBYO1YvTqh6Ls8FbG2IsCteL+Lc/R0gbalMvbjzh/RKt0og57BC6mU868GMPxewMgYEQHCnV6VMT7PkFzVHR7wtujrhqBQvRJ7w8w4vMjcacBAH2OhFz+H4/ewV776uYkvM3o4SXYQ0S64azAwDSJcwRR9rgV2fHOedTGm4Os0aXIo7QE61a7Fs8b7AmzwujhGXRewVLWMNXCcqQQp4pZT7QyOMD/Ybxs1BxqhcHzvp0HcDj0qqDC51zE8XGfAcufj69jrzLQvcckskGdvJqls9cM8AxRi8eWB4gm1ERTJ71Ikieqo4ZcUXe5iOdHESIVwl7STV/PlaaddJXIoyBFfzA6gkKNVVRuKsBhxnSxcPObIoGHfdAXHuUv0nvg2Jg7YPSZdgFIOIfnfAzHIz0CzeBFoxCKtfPsRewYR57eiqQbPENLHGuSrJXw8jj+nsrSrfyAFyFqTbNsTbF05yUUXSKCHkZp7jGXXGcefTSkF2nENlAsAjNNp7U/MxQDxePE3+18nZOYKg/C4VjVIUp91LvASyD86mWxtcCQk3Za0gHDZy/Bn5lzFDe3peeMgPbWzHRrVXxulUrcpRlvVETnhTZbHSh08r1Xb+QBDk24JvJI+EOnOkyiuZUWMYjFM09mY0HnEXgHNSamShyG5REb18KgNI+gNU2olsVxlHPwMdxHK2pBjVnkM1hVA/H/oVrBztux5XtL1OmtBUNrUn1L5HqUpzU3efnBNvoQtXoJeY17NYzqCWQFS9SPVHuWeqO5eQXQpBdLLmBanuOYbZlze6FNr66IwcJGii1rC44mmVGzcXISD1vMuWBw8WcYkkfTc9Hn5GMIweI7s/2zF9DD0D/bAkRUOtHKHdwlfBpRk1b7lSg6pKXVXnfrYkql6ApuzaK9hxQkVRY2AYJBAepk2+cLBSk9ideIIaodaiU+ecSH/jBPowBgYECUQ19g64ViPbEf5Sxg/Dh+mbQQl4W/FUk3TyS3wqStfqR7aodaorjVTaIVLo1EsHs/DpGySHaoUNSca8nGJp3wgkq17RjriCUsSbrhaH7L/vMsgHu3RCLaZ57PDzZqBQyXk+sMO0ShkHyDwGaNwxWwXmJxBcZEVHFyQ7RnT5Na+QIOebZoULT6TUskR+sTRPphTwJN769837xARI283qTcsU6ve7Fw9frzwVMwKJ4vo/GqJR6T0Xqjr1dXBOPWQj8OzeoW4hmaojFAZtENSgZPFnktTTBCA9lxzJDzxP/ZgcHj+J5hb/UsvYuHYOrTWrzDS6a1ehI1Abe0S1nf12vTqM+93kQnIV026TIjv7K5AESTmCo9urpoGN861wGJuuciXhkQzN11emhLYDNwPPrkgUiP2+fQ/WiWHQS3R4/OkibtCXHuyQhH3kHXMlOaEmWQlT61kmOekIYmUMHLodHW+mVeN2vuT8rt2kHjX9mk+uQF1Bu8kJHYu47D26BPWtsUVZ+q0I5CqB6dijQF10sZbWKwKWXT0LxH7d4KMLSSa628wR7twGUTUWe5ZvZ3Bwj0/vl1yai1a3Vl3EGT3nC/r7tYs1C2Fi2qFTxAaLIO4Pjo+4+OBnSRjOm2+8NXL91iPy+rbQL7Bx9eL68fhg+PVOW2+9PXp1lrHk3hqBIA8MH71933Prg6eqqTwH7+4nYpt4iiTkjaetqhNdPu7MBgS7JqK/etNQq8rLEHgrloXDXvEsRRgiyKHBV0K1WVVokxEsaTY/RRtIiPc7+hDIg5W8NCkV68vGkaOT8YPDhn3uCvn3zvNCckeZvxaJCPHz/qnv32qyzAsV7GY5rQs3zGo2f6Tz//fnd5ebF8tnnJL1x1P/3RVfeb330tOYO5EM14/PRH7y/P8RsaqOz9nz9/0X31zU2eXacZa9wPXmJwggFnL6DTGsXN/MBdBLHmDLaa7d51zQKPXumobkBYxLFd31ikY82ODi4AAAK0YwQguDWjNuXFRPpFKNs84mT0ts9ewgPMz3/yQTem+6OxF97rxz98LwMGWy3+M0M+tX9ZG4TNS1nE1P34ow+KbDOiUZgqumSoL8dUWl4XTxogAB5uTMCVsWvNU1nTdipanM4fDLRwtxs9irRCq+fpnplkWwm2yENEFaUQumjQC4Hcaszb3N/RNZINFl5hGRXHU92/AcMok43kj64vM4XyHh88vl68gH6fMOylU14qdzhMc96yqL64SAWC46mvqnp7M3YuDbctst5myI8fXaTetqldzZFi8f6H719W3Tq0xAOfhXXFUtX66i2Y3GOe4bj5OEqoRTRpi9rsWZIpAs2e6ZZeZhj0aApyBC16xOe4MS+3YoR3wHG0bwRwzPjN4BfKdDg1T14AgQlTBz9bfbWULMzFvcbUGr4bVwM3Lr/MNht6t8HwJQz3EM//4PwET+QyYzbvY0YPegYQaC6CxTeaGGipONMkAwMXIZ69ZmhRoy1PEBlua+E+LxEWGX4knvOiHdFE/WDdgi7QDRjl0a906PzeptrJeqE71xRCXNqtXBYawkCBY4/SxJtXaVS27QWVTizUhgGRDPyPX/05zzx7nuuOZqptul0A4Wm2Qr8Rv2eKc3t7NOrHq34AIPD7P//Tixx5mvIaf2V7G+7aYeCAV4gaS5ylZ/CSbfMdli6KcgKaDGtNy4xoVNS5gr3DJImy1uqWoUagvEGxnpnoAq8xLxs+9s34YQRFh7pEl4xOIcpkxv31Ny8Wbg6acziU85uXRJ0Ibng9e71FjX70gwt3wpRdZ2DyEmTQACaQr518yJBsgQvtuPUNAAI9wVTKqF3U/eNsNUOUaHNHFidh5s0S21oDzcswRzVJmknmZZxaq9fwuajIrkiyzbSe2TRVRl+sfknnzPABgAUER4M2UBgQNMpkQDBPcZW8gT23v3//44ujQb3KOgGewUb8f/3tV0U2++Rdpgyk5fjLtSqVvYPd819/+3UVEuXE2LRkxKfu92n01wjb7/7wfDFs7tvEhs/7mKLKrTK1AvZsPcPxC/t4T9Z47yge5RCqKtGNNu/eWmmcSW4t3LfH8CsvMvvRKW8Zp0yp0r9vI795AWzVSxQh10SpAKB87Ggw//wvL7rvffjekiuwh+UYbtPE/CiJx9Gp//PsT4vHsApRE8TIEWjMn8vGr6/Kli//1+7x3lV+PTpwa2JOR3wWyRxlipJ+Z5t0a+UNWrRo7zTMrRyBl30GBeJV76f0vPBAumyTU0/E1CZTIAGBhjS98/y8AkgSpFkbiG5QQCi1smOvklH92+8PBa3SPAXrDgUGMtfP/zxmCnUSu30BBK9dJUBjAGJaZO9loERpOM+9sJGfjV37ykbgOVsBvbV+QSsStKc9y1biDbmB4otyMseaRNvKGsPo88J9nUSEaHE/NXoWzOwN9DiiJ56RF/dJESg2flwLWrXspxzFMA5Vko6jUAwAL4mHYyjt0Nl2Xz9/medpc4YYU0y5+lULAtFS5oJ6x3qNzzTT/VYk3ZQmRdxfaU4EAi8q5M1Cy88T9fG0AwOFR3+vbsijS2sybtUBOWRKVOiCjE/XM1ONoNQJWkGL0nDc/hQIfI0+kKOYaBWeyFPcpJooAAP/O5eNc/YaVbNI4Gmpx0G6ZfCkIvzZMZ6DzZoBcyW4A+BbJ6Atc4zscavLnDfqh8u5BpPueVqlUh6I47zVpZ4oH6BUiQ3cDYnOFDrt1+vza3tn1O/rKJJGl6AbzIgXD4Byh2W6400FAD5m2ysKraIpw8Lbk9Bmr1LnF8ayNsr539nwHzt0Jeqsx9EjPHQeBTcbYC+ADoB4eMA420I9T8huCei7hF6914EKcT1RXtVyrtuvRNWkmizLx1gjzF1h9Hn0d3INrfXMdC00ew6PAEDAuJdtMTe49AKgRtheXo5VeNYAtQAi0SEGjlf96lXI4n98XjQO8MEVNUADnULZNmgVR5QYENAS3jJeZ+kZPEoUdZ6OVrXxepnq9MsqfIpFvrFP6yDnZFpAf6LlXT3NwKO/t4JlK1KkGoK9Ap87OCM2wGFGbfvlSjhlwRxTKRtl+fwSxZEiQN5HzZNqCgjm6Jx5B7SPxMjPBr41HZXLxeEFvAcv4+VdM5yjR/Doj8f3o/KJaLK+S6FSWfXAJdZCeXL0aGOSzXr9FB6DN2AAeHRH8wiefuDX45jprOtwRZuyswWLZYRhQZmYOqHgDyCy50snO5tIRHVOXBjInsD+QJ8UEDzb7kUurzhlsuE5Hi+Z5Dlc9WddIGVdVyJa1w77nnc4zy7cwcJ+LcHsndeQqTfpPovlBASv/Uo08kfFdBcpawtNwPSoMHSuRepr+rMFDj7PHuPly9tsmDAA9gYQ19AHTJfgHRg8WrrAeQmlVJrd5j+tlOUmBfnexP11TranHRjYN1RKwl3GuSAw6gx+dprhaJRP9gLFm6HWatzVCouuq9a3k2dek1/s87rG3kNDqAtYDnUSzSu38L+HEyWahqHQFaBJxu3hITCSMzB0tGeQ8DF4DI04cfgWoACdweshtDUsG00yGlPeAMfgARCC5W6AOMdG7ekLFdxvVdJta7ZZiyp5GWcv8gMPwKHOCiiN5FkhkqmQzosCsUBG8myrJNvTE149EtcN9WnuwGIE1jTr6B2UFb9MiavrtE4aAMGA4UQdUyo9x+AAyBBh0pyF0iamS+wlit5K0sSMmxXw7+GtOe1N4GGgeF7hbAX01sSZ6FrNGGcaRKFRBoJ+sZoP0CI7b1LOFFbMdsU8ZRXBXjIt0g4aTcIkGexzRamBgo2etzB6Fr96DoV8SpVwzqtxGpfFQmoDXMrBqVQ8h2rTVFQvaafhV36+LID44lVx/UGqXqN9XfT+rQBDNX0yaOnYWgLWttno0a4RFMgpnfDmGGjYVPMHZT/Usow6CpNyCNQzeK0x8qgTziEhCe/A3sgM3P5ubg6Fsdu+jeIGFts3ng/gsDhe5kK8rKdlovSbAeWJdM1688y6paM6VcgyRSpBU3YBZBB4/Z0YHJ6XUDr1VnmGVoItSqjxOc4PRHML2AMUiTbyCt7Iv0y3HNayCf7j7HGLDmneQPMFeO1MtAqUyAAwJ/ChqpRDqi+5vNkm3yfjx75ec+0sPo6R/rB8H32Ru9ARFmJcM904lqNPzuKVoE4cTWq1svHOcb6Cp6B6be09DXHW0aSo8VboQUCDJDHG2eMoDLpn2mX2GDTic9kEb+0aDqNG9UMeCDQqBA/Ax3gaJYABD2F/dgzGbSM/vITSpZaWYCN/ubRvX0UyvMK6UPlN9hgAAIdlmW5lqiLlHBxm1SiUB4LnRTJtnW7Kv5l2wNBmAJ53OOuOeq21zXSa5a2UbmQqlc5F1KdKjDFdohFZJ9kUGWTKMHsRoQgQW8IZnsG7B9dwGQAOVNz3zfOXlbHrMRxngKCUAREljTgh2gTBvNQ4Jf3AIMKoD1DAc9hxC38aTUJfJ2Swi9cfpqoBmkajoCFwDU8s4uSdJ6CjdvoXZ2b81nj4SSufkIFB6xcUHiEV0blNu0Q0t/qWFiKYtAKHR1kveDkBjyZtzUUAAOABRgLgnNcxG7LH0PvZufcfX5+iSamocPEO3UVBjVhUKk06aYvTBBvWBwBIDp0eX88eAt7Ay0PAa9j1N+k8X6edPDxqxODAZCL1MOwJEKb1chRn7xmQZ4h0Q9GgF10oePEOyhV4VIfDoRo6RYLMo1JstFpi7f8f9TwDL5rE9+CRfXRyFTzbDMDAZ+JJUNAOBgQDhW0ZBPCgENA5YXVzKDzG7c3pdfASqhkQXVLxzJlsT1wzkAAW1iET5Sqi+iYv+gRP8ijPaJuL2ild9PGt6LXq5Q2qhT9kXTOmQK1WjOoNmObw4OEJY1Ak1gNeaUSL8rQ0A/coAu1h48YW4lkBBs2A0KoBwQxCAYHvTIU09AWLatYbXmhWBTU8B0Z7jPyasAO9KgeqE916lWgUysY5N6GegAGg5xGafZVWLdJQ7dl7BqNJXl1Rrg3i1WuoF1GkATRCpN6g0gFEdziTrFRIi+Ui+qOUybuWjZ8bbmnolD0OjF4jTgCQGbBphBdJaBog7Jh9X2zgrBk46sQeAjoCr1sW/nDyFgjJapYa9Kni/iTGmUIhN2Hagu8HHcFewBPZGprlRB3PpXh+7pN7tByD1zxmjwFA5HNBr1IvORZRJxibTsNU2tOqDdLiOU8s83HtKYRoEK5DxIg9AbwF9nEdd6HgKk8DBcSzfVfwBByA4GiShly5+xx7E9YPTKHseghm9QJcIu5pBg7RGm1DOFa1SiSqtRAQho9JRo/zqqO9K87fimiSt3QTJ9GikgqlTYUmIMM/db4bisZcnmErDdKq0yippnMQWCTDqAEE6AIGAd+Hz/OWQcUeAVsDBDwD0yXNNdzlAS/BIziKBJn7w5DN8A/TlCkRi2yc90K3RULv1e0a3bK5EdIMzdMTmGTE/Z28NevOrjZJm/Tih8uh06BbtdKhSiDT5BqdeKN5gYj6aLLMo0xRWFXPsUhmIOB81BmEr4uW9NIYvAHhkTXmOo628BKIONlz2//5Tz5cWkJa8y7vgXNoG4n98vr3nf330+s/vPO9sR9d/7OffP/vk954QhGyZziWllIuzuG5t2RaP8/z2QDhN//+9Rx1lagSYI1rtFkvd6LQ5wwSaIiJIjVRviCKInmlE2y4fA8e1XXEHyWLzd4DYNHGCQDE//rfv8newUDAnsIAcpvKNJaIy/Hcf/3bH6e28e16K28w2hqcIh3n3dd6MkGjoBMe7+v2r5/8oH+d9ndWNOnoAb7wXHhrTgE/d7tY92UzLi6gK1q6oyeRRGqimWWtGiMe0bnC1IsOsUhmmqT35qpUz2OwJ3lB4tD2HyWuDFFtXhb7f/XkBxUQonKVPWDREHaLqvKDgYAEoPZQLb3e9Prt78wo0tJAbOq6cAG/1g/AX77y9ILTyzwCzSB7QGol1BgAXhQIJdYY2Xl053btbPCtRViKvELqTq1Neovv9aZeP848g9X1//B7j4rXa7DBa4C2tbBKNIDhNYdlhdGLBQBLWPfiJNRbxj8Ob37cPrOlb4dnrfaMUULMG5EuyBg9isNGfntodezzK0o9MQ3jxmtmaQjMngDimZNtHvdnAJjBKi3Cd2UGzUb9iPsKUXLNjl+kdvBPsIbC7a3rBTwttkV1vCgdj/4wbEzR5P0towdg8Lp32jN4EaBotJmcxrzqGbhswhvho+xwlCzzBPVimOPgAqTTXMVcaghQotaKQ94DwBipy7WCiOmRageL5f/0R493fe9b1CjSc5E3hzbwqBDTH/UOrBfeBEU6vzzDND2JJtF4o1D2AMn4dZ5BAaS+HR3ycgdbeQYukTgcyvaPTIdAj/i1LIa1/EKX8+2DFX8MEPAWy3sS1WHjt+0Lqv//qycfLtQkWknIM+Bo1N+iUYOI4AgILJgjbcBe4U14hrOjSR4l8n6MQgDzJJt5mxZtUaCIFnmtWFj48ntwSbUaPwtpBpC3KAu8AO8DAEqNWp4BDwuhYiERpTJR9t7TD3vFsRm/x/+jUR+GrtEkft2b8gxnvdrn1g/B2WKuMNV5xxEt8nIEXm5AR/SIcmFhD5fvHsowKIOjFSGa0/8+k+FuCWYGBHuKj77/eIkcRTQmquD1hHTr90JkiF+z5QUYEB5gokjTO02T1DVzC0addpn357K2yEucRV5hq9T6IEV7PLLz2gUKGB7pMRmnKJk41KsRTWmLa83gJzo3JmoDwcsA4mMcNQIQvv/Be0vkqNUmv7W4YvW7OHmeQzoGIMArwHBZAOtxNnQFzHcRSTrbaFIRGWKaMlBibK6Xb2JvwdQmEsN7VsFRQ8cIr0atpRTlutPtZXs9Ue4JVoADwhlbHsHt2NXlxQKA3M7l6A2wQmdU3bvVMtMDTnRO8waRF9BRHwBR2uQ93vloknkG7SjBzzta9pXLKTrKEejayF7SjMOfHjigDUYBFhs5l1AwIBBeZR2hAGJARAKZ6ZDmEmYRsGyYy+o4N7fd1fGnte33jh7B1nPem7Xfk2FmT+CJ3EgEt0Z81Qd7vcY76xl0hPZKrXnuAbxDKzrUihJ5r2OP4OUHeBlY9ggjhVe5j5GGPbEIiy4Fq8c0OgRAQCOoVlCub0AwmmSRI++aVjTIo0kehVJj1iiPhk2V77Mn8PRBFDX6i9AMiCah+4RHFbhtu4Y9dfHuPS3dPcBoNwoOk3qagM8zHWMvAA0QrW3N/6uK4yFRIjsOrzA3GhmAJv2Xv/lh5u86AcqL/oRLaqXXsgFylEgN3AOHF0FqPSKD9wD2znoGeAINm7ouvG+vbOMBxCuj0NUsvUn4urg3H2cvksXwXBu8LjQO42YQqDfA/zvLiN473wsM3LzC3xyp0TVNlm99395MQC+Sp9Eer5DOM14Vy54X8ehPFGJ9U4+zDK1qP1IFgBp1tL5ZCwTK+yeEL6mGyDP05Udhg5Ykmlc/5JVYsKEv9EeoEa977I3WiB55ozmK71o0ak9SswhkUNlEVFHqcX8dxVkge7QoOhdpi3caDFkoD+XqMK0GvFEnOgUER4/YQNUrHOi45gNYIPMxDp/2lBcYJKRaFPORwQMUGj0aKNTaGtXZ0C2EGhm4Fwny7jOR0XIJhechWrkBNX5PU2yd92jS2XmGf/vD8y9T6O5Xj64vfnUc0b+4bzQJ8wq6aSpqi7yIT7Ea5hzrBK8aFcc5iaZJMKVG/J59MKL2TmkDj6pcV6Sj+5wAAQo1kLfw6oU8vbBHFCsgonoirixtCdlWQkz1RMT1o3BqVMH6ukDx6ubwi+Pf390bDDaBf7wYPz7M3WffvLh9crg9PLXjV5fjr78NOECLGBCeQXvZ5WhtAw6jgsbwZJtMRZzokU7K4d5FXpi08BRIkqXnI4FAQ6fYLkZIr2uFPVvFdK34f6vzOL8WAlkn1ahe8CbdePmE6F7eqK9lGV4u4ts8jjb18TTNP7Pty5vp72wNQZt3f7RjS/Z+8Tpp0i/H1KPmiDQDyBObYmdvaOA4/v2TbfeEN6PFv71IUESfuBGXdpxYvACBQGeQ6fTMJVqUzmmESHXA4Iz8Ghbl0d7j6XyuVRqx1QQh0gAR1fJi+1vJLu9aj+dHGefI23il2ncFgRn98e/p7e3E9viLjn5Lmkb25b2mff7+q5f/OAz9L9Yvdk6ufsz7xHe/SB/iy+vL4Z/Mayg4vvzd17OXMY5qirxMcrT4hybCuEMFi2TNJHcikJn7Mwg0UlRoEkmaDUKXVGfsFb6tbHGLUun15gVAibziuOjhjfxb4tm7vhU2bdUs/eeff9Sr8RvtuTnMHxtLMVs7Hv4F/y5Rgzqzz3uB4Y/fvPoH8wjrj35wubSVBaBbAkoEjtdW4PjTNy//YSnjbqxk06pMjbxGa3F1zihH13vzjUGDolFcqVBrhPa6gLcA4AlgDyCtjPOekukoihNFlLx7RAC5iwCP6NhPPvrwE6U84zg+8RKd3hIGp8Toobu8tOLF+df3BsPYd788IrEwfABDPYQuGMEGhmvtmpub2yLJ1oogaajUK6vQaMzeifXRQxNeCgrOIMNjqHeIKM1W36e9E29aFIoB5XH4LZ7vGWZUcr1Fpbben48NKeyNPlpFDuR4jNcNt/MjzaW3c3g+u4PW+KvXohl45B/NAGeIyBlv1DGVyovSDWO5zcY65mvGcc7IzrkHr7huKOkPh0ihEUaZCrpl7JFH4KK4kcKk2dCdbPLQiDJ5I/lme3yZdO9ljb0HqNCNgNITqHuFbiSK90SPIm9g28tUiHjqabU2mF5s6+bmOKJfZkM/UG8tjPwMANtGDMHs02jVvcCw9KAhIFwekXCYu4oSMRAAGHgT9SQKmuX8ESz98bm5M1yLf7pz+o4qvdGOFAeH/gBQ/IXpJPzCuwT0J6JIi+E6Brt3vnf0ur0UCUBocfmoA8VWVjgqudhTV8TvgZH/Oq2tkRecsfc4Gv5A9IeBwF6BvcHxYEGRmIXA3myb9j+/FxiOxv/FIlCOlgSPwCM/g8SM37bLj5L2bWvX2P4kXxzOAzDwPrbNSavlS7nIVOxEqw7FjDIvLOplhzXHoDVEPGkeIVAWwpM8Z6+gBrrV8rKlEbaA4N23JWj38naPukRTMiPq49Kei3WNhrzopCxyOSRuDwOH8TPtYQ1g+6eBdczn8kCbWAiAwPT9XmCwcBWP9IuxEzBgyHYue4C5K7a8P/YrrznMtWcJvFNhtJeLW52y55imei6yJ7C8Mgr2HmpwrAUK/RAksbZmkU0ODdszbyACUMTlvZG8Vf/TAsaeEZ8fj66vlkHpelxH/gtaT0N76vL/aufKmYJj7QlocGSKjtFfqRF0amIb96NJR+N9BkMGRaJzxw96OoZz9ofjPOovIBhW7wFwDQQs206ORoEH4X8M+2P6sq6v++w9uEeSVzPkJdRYH3h9ijgkivNDIyu8pyla5CE8j+B5BYAyKo/YygtEI3/L0+hze/+Tca6rrJoXWDzA8XleeJIXoUwjPGuCTIkhkHldDhLLJ++xagMAQT0B03LYkkU17+0ZFkM2sUJ6QEf+YhRPBp4FMhk7A0KBAPCo3mDKpUDR5yfP0RfRrMV7SCmGFyFiUDAgvLnJHj3y6EtUCrG3nKIFHBbLrdofL7McTcZpCWtQHp50hdHfrzZYV1syPXCTjB/JTADBjg/eoJXo0EJzUD5yebFEIhFChfGfyltWTZqMvwzmdK+rUI9c22K8yzxHOdZ3zWal7DUYAPAq/KHZC7Ee4fdhQKjXAtCOX3PhPewLsx/JvtCZNEA2oFQzFCW+Zqf4bU8SzXtN1EA5uofXiiWK13sRIc/YPaqF51dXV8loL4qZh0x7umEoWoXyPgNFDX4Z6TPtucw6wIsSFUnQox6oFsJMARjPG0g64Nm9aZJ5BTN8BsDBiV9GGqHSC3R8GFYjhtDm1y9UKHkRPJ9IcPP91QvdiOsaUzSJRTmiFbdJZzAl0nxBq/GZNz9gamSbo7XmtvRCK1sbFcxp6YMHGuwz518MPvP51QuwJ1j+R/p8AAMWnYQOgDiel7ksB9frcenESFEk6DymyawLOLjCngGAwL7Z8v1pUucDwMBhxwqDF48ReQcPLOwZGCwMCvYOeg+maOotllUoybsAeIsWOX7hnPcwr2Hg8DLPurB6qywiqkJt0aDWRPkoG9wStlHmeKB+saP8XFpJnBNgaSH6sjziUB2DV+gSIC4perRQHrEPeAX1BnaMk7WZ8gxjEVjhYxpwYZuyEo77e4bupBkyKBAtyhMHkufoE53qa5C0AKGgUH2iHsR7DaE/h3aZYnGkK3sEoWE4bp0mltdfXeZsOQR5FEpt1QV1DaE9BULXklGTk/iKQqdRgqxo3GUBAglHL7yfKgEqoKaRXEd7L0qE63gdPlAgzSBrNpl1QR7RQZkoSmSZnMUWqPqBB0zsezTJ1mu4Xwn3afGHk3GTIO7m5IaUAgEIci1Hmnhfqc1ioABW4oYGQg9AfEyjWS3Nwd5lHHtvBCn1CVGq4dFpxZqDrDut2uAuDblYC8DQWRh7XD9KggFIXCw4dmUXko5WMy2AwOvaNaibJ5g1bIoQuBca5byBllJg8DEaOwxcAbzSLAMEU6Zpmt1AzuXFutxXev7s/hnoPkWH+vKNF6NIYjoDA4bckZdgwZ08jAeImjLM5XH2QPIavhfvewIb3mEcy1CvRry0UpCFvv1QyxecIiLgwkukIxDLkTeAF4hKIzzuz9ddUnNinprK3Ud4ei2oEOah276FQ1/dHvK/zBTP8wSqEXKuBiJ4WvNAnDjTWiKABRFAAMHLGTAw7F/RpBrTpjyAM7M42vL9o0l5Vc66XmnIonbVCvnDABysI9I2L2I9z2WkqV+NXkFQeAyPjhG98rxHAZDB8RICCM6FcGKxSEDiPY4/6NXl8ce5vso/GDLlxbxmRwu0xHLE/ccU3+fFEocU79eOHqj9YYAaCJAVxqqqyA9kmiPCWPUBZ4MLwz8cigqCwvDFE6z1YKfvdp5KeqOimekRwqeePoBXYC1rz1/rHOjMz8C9+77iZ5m7TSUAOg6JJWN2DTfRLGgUgAAeJgNAdMlhR4VeFNny9lnAc9gYIGJKpSUonP0Ex0VItxU+Va5/SXMo3NooWhxFPULHTReoCduUOxbOGRQT5QXY6D0Q4NiB8gAWOlVRDC/AtUXI++Bc4UUS/Tn9lqs3KAIr9J2yTvRyUCO9DrZxb83ARg4qBBBUozdVmhYfjs/3fQWIy4FANDsUifRHRY92RLCqJKEj8r191jhe+Ja/g0FKTPhHu0qLidhobq97dVOCg0d+5vwKhHEcXCAxCDCdNtdIBWvawaOoKF7W3iZgqEi2LYQxssanAryxigiVZfVjBlAWweNYGLYmyfi4VxiqgxbobES1760ZsPIiC+asH/qaHvExN1M80z/eE8j6sgSj+jLSfT1KVdGgpHOUTrVyIKo7nMhada+K4jnJRY5k4ZqFUs1r5AoRHhthuWNHtAwuz9XgWXzIl0zUecTenhd+1A7mEL4cEeLyiiKRliJKQ4r06JwCDpXmkT/tI4GXhS+8wjAWxswlFUi0FbkiTqwmppBzVEShPTp+P5q0JFrmwlDd8BVGe0M9RYImpkp9H79estytUBm7v6xBREtkgAx95U1cKobQce9n1rN3YMrW19GxKPyr2gXXZZqVDOpyvMrvi7IDCFudutpTHyge9W9JIHuZ7QtUjOoaeV2dYQYgio4aySugZEJBgJxEzjdQWU2fEmT20SCUudR62U41KLQ0J39/aZDOkaN5DgMy431Dq2qgvHZvRnMyIIjoxSVfDJW6z/vc50gBkcA0Uf7A9T6qQdh4u5VuMTXjEd2LUjG3LLRIQJE8o+cQM/8wEf0qXLrcF6PoB++djNMW/rZRmPk5JjMhCjM57XcyNTpMVS2RZpC1rog9w0DZZBa/Os9gJIqUQ61OgozFsDed2Ms46++RQ+rTGqjB8yIx/DpKuLul2vDkHbDF6DvNq3HmxbPT9Zn6sMERwKZZPMTclZSpDPxUniYq1rsc+6K8l/WJRqrsvjdTV3oHyou0tIgabjHyD3XS0K3lGvpmWQtEO54bpVoAdByZrc4K2fJlQtEFssRrCBXhUl72V8OiXEzHdAgJMwOeR4VKET9WOQSUT3QU+rRIEVeYrp3J+5xMW0LeF2P9u6aRX58zU+DvEt8tg2Sxzft7htNonVeMPyAW3WcAeNGkYfEg6R+4nbIuyKM/jxbzqhugKdj4PcqkIIo0StY6ROEAmAIgc/llFoLfOedSJTHwIkKmdVpzrWO26BYXIS7HE0AWA7HvvD9IIiyealrQGKFDDAx4AQCHI0HqAcYEsDGN/Nj3pgdDROeq06mcSswDHOgQa4CtwImCxL6ze4HhaPxfFAa1jCh9NeKDGoFCsWEuXmUB0SxrM5dhWVyjI3+1KPk0FyP+FEwS0shEBlxABVmoF1NM9Qt3eGmRaOx8gy7o2FwKcr2P1n21ylqKCEoytpE6hINamYEPZOSaSUZ59ZSEOSpND4dD0ytw9riIEHVriQVqjFgLcN2RJs64ZL+oMCDKw/anXkETrhlg940mMQjspmawMNoFGPOcAZI9BcDRlwm3BQCkF/J9QLOSO7slT8I0KXuH3jF2hH9F6FfXaVhYdY3OtXaujyglG3mRyBvWyl8+rkCD4R+kforLWzwh7oEFc0bs7/Gjq6JBWp9Kr7nKFFpkoDnI3myzSiMkz8ElE7a/jOSpnPo0VXalSOuyXnOVeBsoIWp0iL/PIlE7rVvNKTA4MuPoXsN8BqU0g+Yd+lLUQlvwMUSk2EihP/LIngz/ZJiliGZtUiX+xHvwtXvi1CEoKBS8BAdEyLOXGmg6a0G5UH7ilJaAPlXUaygz7Kp5GCjVPamYUmlEzphTxxL7/NeI5NAEHDV4L3+wZrrXUCpGeBi+llXkCmQushvqRBoqkHP0TgRyppfpeLFlStmXTOL+YAiSIFUvVAJK0Tk7eYCTgJuL8GemVuk865AsxLuV84OCVQIfx/sSCAAK07ymtpA6+EpPODkUHSwKr0LlJ7gOEa/CmJl6zQKAztc1KsRxz0rzOPkQLmJcQJTyHtfXV6luayzas7iegXIHTH2WTifiCXItm3RIqYrrJDdT5JI4KDHVVJUBcUlBHNKWz15LOYYKZKlhc7OHOfrEo/LE2ev1AxfXJgPP9yUAQVewbsnCngBReAgHLAw2Pl55jnmuIlDq4SJKpmDSCt/MZSU/Um1FtxSJJEeHMM3arNFywslroOIiX2sZc02inYrfujpPIHOS+TvJq6PK4JODAjSR7MD1bUw3Oz9kfsDg3IdVEfsL9biJK45ZX0tG96WTzYiSaMgws+iuShXIu8A4swcpQNXVIGOAJG+SW8qTV5gSWLxU/1oCMjeBPQXzvas8SSCYveu2BLo3srOw5ChVFNHySuuraBcZXlQmj4z5FRUvsvFzSJTnJPdV4+W+igzmgUPq0TQixLqg+B+JJmFwyYNMX3rqTTC8eHX7SwLAZ8XvSZ0GTh96yChmKqKlwdU/2tV15zD86rq5K0ZtjO5Mp07nVwoGj4HaKaNWdk2SizlJyMIfr9MfikcreKHif6CRu6JbQQSJczKdUkkqf9fXaeZ9opGdiyGVcvF8EKZXyrE1+lUkGAUkOndkKUbs1wjWWnk6VdMvvcGTNYCGTQvBrMkznB8oDN9vD2RNmmSe4MXL21+mL/OzMdCW3jJNNjoc5qn8YeBGgygOKiWjyRhar9SiXtOh9CA5PKsgGfsiIsTiP9MnuH36sZZoFmkPBk1RsEgg8CgXl6MYQIuQMQm7nP/wWvGzQF+qOxPApkYpiUOfKoqhZfXiRbSMRbPqSr/wO5kX0W6KnB/J80n6mNp5EaKR+3IRdepmSco6lQlp0PXBYN7AOhtbU+GolkO9gyemlwzp8RNdEwBg9GrMSMzkojEdMcwYunbCjbUKRsYhWMgBwCkMiUZ9HuVh7Jj9hfO3RLG8OiwACsnIXBBGxY2R9vKy6oXH6fuiSrjoTN6XQMvfWVcL7UWbiOep6FNf0jQ3i97V4d4ieUgec6kg7+MKYkQPOVK0lVHWoALPp+HSoGjNj6MtfFzlGZ6/uPnMaBGAsDeSpPv8HAKVaVKZF+iruhc+dhpdSyBcjMNmDoGPe9Rd9UgO6dI9MsUiOmbnkCfJ9Iuy58U9U5Rr6LvCgzDAdP5HHq36rpgTUg8QQqOCjGumd71D06RQUktjxiDczJXBLGCZjh1oJD5MtaAv5rVLAIG9j1eWMibqVAUMiP5wwtVbIrm47kiTBvUIy1RO0QZ3AYX3pXnNiJe69b70CqcfrM/ewysNWBNyU9WDNQLoYrxj71Iv5Y/8r2Tjl38PNKkSssT/M0jIwHAMr+eFGZccSU9A6+L5u/yZWFvxD+/9Pnq/IuwrYVyA2wXYvApQzYXYsRyS7cVItcS+K5OLkbcYSUccWgEJGoh1wUtvAUzJP61gWKJFJ6F8ZyBwtadXhoDZRrfF6p1z2Vy277ORBxqmuPZUVzPn1+kxPlflDvrezSewgd0equ4JZYQpgQVA05EfQp5HcKYxw1DWWbEeyZ7I7udMikJykfVKMSD0K9XwgB+Fet3QsXoR+uz2lyOIs0Te6H/jTimZMvV9VWLiJgslm8xZZD1eeNrG6rDesYImJbF8JyB4hWRaFsDHPINkD1GN7M5xrokHfQJYUI7MgrxrlCADRG4ouO/C0dkFGCUPOYuukS7Om3CUKwOwX+lZFulzUQ92KnnJWmT1QLlMRb1c3/tUkcOMChoJJ1fCuncApetwk65AYpGTZJUo70ovUNChvh5sK6AkgB6muSqbYZBg8OKo3fHYaYFD5AvuSouW+bx9XCTmnWMR3dQJzv7iHYa42G41whUUpxr9qUziLE2s0KxgDumelyuIKKGK8UrAkTFOnphPxs2eiXMma+IQlG8tB1HRXglxScApl+Ywrve9uv9/QJ+qOSUEoklCs8WsM9Ya6h2k/KTZc2uoo2le3ooDLAML6LQO7md3AYJ+KC0zbmas51IAs3ZojebqNTQ0C6/BYMNzplOFZ6C/NQSbVosZ6tl3oGA4j2ND7wv3YsRFDmQuk4hsfLcpacWZcc2XeIEKO4fX8P1tC5BB9BejJr5HqSHTcHClWQa/QFGrhKP9Imsvv+049NXAwoWM2kZIQ8Oj9LnKn5u0Kb5n/E7mGQbTClvG74lTBUQ1S6zvw0K3NbrRV0k5pkGVpnBjxGUkqlrogr2KlAyo4a49Q6Xl+TRXoEROBNd7AA0FvVNVC+PjQkaIaqU3XOioczZgOPixQalwTEdozEWB99HKYUSqIOyrXIjYCf9vRS+tvuFho3IXEfnVNF6JiBWRKK4S7tZ2QeiOeCBdmH7/JxdWYuF5Ba8Ab0s7VEVjWv9RlRzMlejNfJ8mhmvJgoZoq7oY6tiMbaU5KDw7jDI31/MgArIi/EqtVfC8G/y6rSLqw6JXEn5Ftls8jSYXc94jUasCgAt4OtIuXZHoK6JdXARp4eBxSO+NBetnV/RXRi5apFX9y2DTOfGt94Hx58GC6CC6qRT1TF4Fb/oOFm1rNCmFUpuub1e9vheBmOfQq5yoQG30GjniUGoUgoXXmBozmzSM6+UpIm+TKdw0Vx4Kn4vBpZ8jA96heTzKVrRqqIUt5zHY8OEhboVMI8fBQAN1wnwT/FaIXnHmvUgOUtJPjZ5DwjlEPPZVhKugnKIbtI6NcwWeFyp+N4pm5bkuCMVSmHh0ImYjD0gKgjsZv1Ai5uCbvFEMpqBLPJKToRV6QKhWHumD91BD9rxBS9QrgABITgyCanl6Rz1glKwsWuwHCcahL+dzZ2Pr19dpfRULeC5DvxhLwwZQ8vx1RMX61cBxDABa8ieHuYja8CxFnWfiVQ0wNcuh594voyi0idNtBa/L+oOjYfNcNawYOc8wTXdbD7oQn/2+ZFxYFerQCXd0pPyBNwLDo7A+YEPSpY8iHaLnPOOOciXq1RTk+Eye99PvAYPC4n2msjyaPZxX8sxJQzfJJhwfwh7eJY/MVKeVRf/QFzMbtegPHqdIQHIFcF/Xd+k8j6qawKne1ariKoHqhYiD5OUCkG/jDaL6oHBEbmSHW0LdA0WVxR7qkRujs9Y5eZ5DS0Ja3sPzGHGeQnSHEyzw3lc/j1e/5QJ0Kr2Px7fd0mgR7wwieAGdGchRLx51F49CkSu9T+GpNNhAwj7fp1+LJYvM/Nw17U2DFK7Q19f2/b450BXPaxh5M6TqTAKKOHMrubXlxQqQ0mjtfTk5BzFrdCc2Yo9OtfRGVXZCYjuKgK0LgAyl2JdcihY1cha/8KZDSTdVh0TzvtlDFMlBuUfhKZLW4H2ENrPIT8K38Cykc7LWoVBwzsXMc1Xd65bIex5hLgfZcpCgfqlh7HgjmrQHBG7MPkBp6708+rR136GvJxgVeYdpLsQ864c1j9BX4l65fKRRPMAwqBgkTOE86sYRNaZJfD/1hFruUiQfu2But1PCwLrkwmvxSQWKRX0VN4GYy4lZg9Qv5TKSfs3H5IBBSjzmfMmwapaBM9xUnaoahYW8hJifHY9J82Ax3C13tCWSq2I4MbyKwzoVmlueqeV1vH5KEZA88GqOQbPnmd7k0anWE62oF79egdH6bjkXU7yveD3+zJwsxOo3occrRv2ha2lL/b64Y4oWzWnpBowfUa48S3GtGaqiariGy1KK+rKZQswy0aqoAqDvzKZ9mmf48vj87+8VTg1G6Nb5rYrKFi0qEncO2KLOzcVk/gaFC8PB7EXm2S1bYC3A+QcGkWf4midpRcG8+i4tQ/HqvDIdlFIXAOM2tZj0BgyAiMHEx3X0bX3HnFzURKJGrdgDVbckj8KVwKotiiz82Fe1XglEz4bjP/PFUr660wNs6QnPcD2BvAcU0fyECFTqsqsRq1G96VWnRvTQy557wGXj9EKkSolUP0TZ+Cj65Xkt1Sgc6s3vL8nDKMfDn41zKkw5W99tVEEKusRNGqq6r6EsIwFVyjSKChpzg4eZdA6m9qaoGELIhZdK/9jnx82nezxCGG4Uzhmn17d7E7WEedhpokGn9iQUlTdv5UYi8HpVtwwILyrkAaKVIIzCvlHBI+dDvM+Ba+AZqvdy/v91LYfVo7BniTxH1DXEG3CobqjQGVwYyU3roGVyh0Yp+eCO8dq/K89nMO/wbYRxK7scUZP7CPHIsD3PUfU42hHdUq/geZQtADYn5Ax9c0DgiBEbcEFftBYrKHn3vIeKd698Xj0DZ94L8CSPwR6CtVH1es2m92V43Cun9+wll8mLmGc94c3qgybRcpKiaJB+iNU77PhSPXfa4v17vMLreESCuTUvYcuLtM5H4eBWzqWKrPV9FVzIs/kIFHWUp3fLQJjS6HoI/Fz3W15FPVZrKVnNuHP9GScnXa+oc+MpPHwCsR+UYerVmuHIjem0RRGD4YsUWfo0ip1H8w2KHzoweOuK4IX8vgtgeF6iVa+v3sDLgWz1cvWA4XmtKNDAybMKBMUUz7kMFwvd4r+t6JZm5j0gVd9TI89SeDaJtGmZvZt4HPqizGVqFH26RYABXddVoZKW+Lif5Z/BRJ/jG/+jfgnRF1eMRO7E9d7A0FO5+OcpYfQUQLw9zdx4yp4qmgL6XT1UBzWnSAZGHoVpW2UqXv9X755u20snR8FeZk8+w9My0TWt13AUjc950TUODUfROr1vngdPx1vfZSvYctz/dHBG8F9buPX4Bp9EiZ/iw4trFiP59PihnwIInjZJQPgYQMA1CSje33f28ES3F6Ha4wm2Qsse5fIAFM1CY+/g/vBOqYdXcqKJuiiapZ5DxX+d+Z0rnePRPm00p4WNXhshDl+HU4idKuAKbIGQ+yLlHz6xP6VJUY0MIf2TBITPYewMhON+D6/AAIi2zn7/XYMjmkwf0a3ox2jVCG1FuSI6FmXgW6FqzWsUo7FDh/m351E9qtL1mEQ0310HVs3Oa+6EvUsk/rXc3p1PrwNT9OOb8cFLJFB86i1OJyPGpxDhj64ufqVGDVBgS16Bkf+x91mYhwq4nl4EzX3epDaJwq2et/BGpC1aFJZGBJl59UKtLH5l8M4xr6yDaY6O4qpFWl4kqhr2Zi1GQZvKg02zK+6ZkrW+/+WeWz/6YnRjV1CZdJOfpX/qiQnvBJpdYdqILkVeQR72yT/2aBa0B34k8T6fM9eMwHNfndKspGxk51uAaRUsevzX0zmtiJ+njbzJRt3UFVsOuTaz58tsvdJgtzRJVNOloNJcznJ8LDuo5M81rFs+lnTKs0pA3+Xh6YBIG6hXaN3TA433er1X5FX0OAn21wKA+wj0vTRrryjcI9D3nt8CnLag36omZiHfLEZsCPTNkP80V9W8nmh3ksGf3AsMr+vRAkgLXC0Kpq/VfYtoKRiCCNdZPbaiSnsTm1uhya3IVQTelpfywrLIQSiwQHG8sK3nWZpzPeZ5z3f66XAOPzCP3rxlA/cAshGd6iIPAq1hfxK16h3q1XE0K9In4qpfa/QrokyeII+6V7Q8T7SN8iIaHWs1UG7Wq7lt++dcZu7lTrwQbqsAUu+hCUVOap6FZ3idniWiTh5IWp5mw9t8zqE+R3c8pff7/LumW1vepJXbcNcwaHiFzbkQdzgfgmeOxX0OGgT1XS3vILrk03cCDHvpl3qaSMN4GiM6ztqDwPFU3mczgfhda5c9E7bC7G1DS+yhVBHgNj/zXE/CcgMCG8I80CGfDO+a8beiVlH+QikajjMVYwBxWNhokwDBe/+eZ6Z5tEteG9KsNxUu3jPt1iuR3wJSVBJxl6y8dkrxAORphr0V2On1T95pz/AmImRbwt3zOlyG0tWZ9ky74FUEpJ//R3uSrfKTlq6JBPqWBorKUbao2h4PoaUr6fm75RnehDfxPMlW2LjhkVzalUR8r0DBa8QbqPDv3rT32DNrsXXN1tTbqOQkKsHXYxHohr53PwO3A6Vk3Jd/8WBohXSjffUKTL8QBYtyHPreQrk8fVMZvryn99nfKKW6y5TerdL21jz7VjRsq6et14eL8xBVuNaSyA/EaBske/Y9Q3UoV+8Bjq9TYMmx3gOl6hCEhFsNzd4UOKIw7V7q1ar9ukvXlKpDyrDdSfxBM7xBrXFXPdIK6UbaJYp6UflJ34qCncujlejzwNOaE3JXTQPNcPFgxm+WbrWuuQs4PNG+A3BPG7kSN/NOj8+/S7G+d865GnlrjknrnEPfHjTDuQn5qJaq5R0CndJHACTKxmK8E/H/lM7fZVB4Y9pkz2jfEtlbCb8HmvSO0rKtGq0o8eiFiiX0u9tTON7nP5R2bdCxpw9geMsBcNcCxS16pYnHViWwlsyTRyno1hYQ3iRQWll0OfbJAxj+gsCzVV7/bQDIgpzrslTk63ySKNq1NefkDQLm6YNmeEe1h6cXWiO9ag9PtCs4tCyFRbjz+qegWkqf6DXF9nVrEA8ErDcePMPD47XOJ9nxHnPkIfSYhIXfdPXv04fQ6sOjGRbeolWt2YbefPeUOPyYvQB5rC/kHOuhLsqbvC6gPHiGh8drE/F3jWy1ggB7Il8KPgLvrHRryys8gOHh8UYBs+VBWsb9usDB4r1JkY73eADDw+M70R57hf+3fX3L62g0y5yAB5oHMDw83gpwfZt8SjSH3gOdXfMAhofHW+dN9r6mlXlnmoX9hzzDw+M/9HGf+SRb17bmrmuu5IEmPTz+Yr2OV/D44BkeHn8xXqdFkWz7/wUYAE5vjnCRyonIAAAAAElFTkSuQmCC'
            };
        },
        filters: {
            // 时间格式化
            time(val) {
                return moment(val * 1000).format('YYYY-MM-DD HH:mm:ss')
            }
        },
				//加载更多
				onReachBottom() {
					this.page++;
					this.getFootPrintList();
				},
        onLoad() {
            this.initData();
        },
        methods: {
            // 监听日期变化
            async handleDateChange(e) {
                this.page = 1;
                this.footPrintList = [];
                if (parseInt(e.type) !== 0) {
                    this.startTime = await moment(`${e.year}-${e.month}-${e.date} 00:00:00`, 'YYYY-MM-DD HH:mm:ss').valueOf() / 1000;
                    this.endTime = await moment(`${e.year}-${e.month}-${e.date + 1} 00:00:00`, 'YYYY-MM-DD HH:mm:ss').valueOf() / 1000;
                } else {
                    this.startTime = undefined;
                    this.startTime = undefined;
                }
                this.loading = true;
                this.getFootPrintList();
            },
            // 删除足迹
            async bindClick(e) {
                await this.$http.delete(`${footPrintDel}?id=${e.data.id}`, {
                    page: this.page
                }).then(() => {
                    this.$mHelper.toast('删除足迹成功');
                    this.page = 1;
                    this.footPrintList.length = 0;
                    this.getFootPrintList();
                });
            },
            // 数据初始化
            initData() {
              this.getFootPrintList();
            },
            // 获取我的足迹列表
            async getFootPrintList() {
                const params = {};
                params.page = this.page;
                // 起始时间和结束时间
                if (this.startTime && this.endTime) {
                    params.start_time = this.startTime,
                    params.end_time = this.endTime
                }
                await this.$http.get(`${footPrintList}`, {
                    ...params
                }).then(r => {
                    this.loading = false;
                    this.loadingType = r.data.length === 10 ? 'more' : 'nomore';
                    this.footPrintList = [...this.footPrintList, ...r.data];
                }).catch(() => {
                    this.loading = false;
                });
            },
            // 跳转至商品详情
            navTo(route) {
							this.$mRouter.push({route})
            }
        }
    }
</script>

<style lang='scss' scoped>
	page {
		background: $page-color-base;
	}
	.footprint {
    .rf-swipe-item {
      margin: 0 $spacing-sm $spacing-base;
    }
    .rf-list-item {
      padding: 0;
      margin: 0;
    }
    .left {
      padding: 20upx 20upx 10upx;
      .image {
        width: 260upx;
        height: 240upx;
      }
    }
    .mid {
      width: calc(100vw - 350upx);
      margin: 0 10upx;
      .title {
        height: 88upx;
        font-size: $font-base + 2upx;
        color: $font-color-dark;
      }
      .data {
        display: flex;
        justify-content: space-between;
        margin: 10upx 0 5upx;
        font-size: $font-base;
        color: $font-color-base;
        .item {
          height: 50upx;
          line-height: 50upx;
        }
        .iconfont {
          color: $font-color-light;
          margin-right: 10upx;
        }
      }
      .state-wrapper {
        height: 48upx;
        .state {
          margin: 5upx 0;
          background-color: $base-color;
          opacity: 0.8;
          color: $color-white;
          font-size: $font-sm;
          padding: 4upx 10upx;
          border-radius: 6upx;
        }
      }
      .bottom {
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: $font-sm;
        color: $font-color-light;
        .price{
          color: $base-color;
          font-size: $font-lg;
          &:before{
            content: '￥';
            font-size: $font-sm;
          }
        }
      }
    }
	}
</style>
